public class UpdateOperatorLevelRequest
{
    public int matricule { get; set; }      // integer
    public int newLevel { get; set; }          // integer
     // boolean array (e.g., [true, false, true, ...])
}
