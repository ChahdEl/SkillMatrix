import { UserProfile } from "../interfaces";

export const fakeUsers: UserProfile[] = []