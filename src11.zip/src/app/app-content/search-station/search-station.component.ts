import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-station',
  templateUrl: './search-station.component.html',
  styleUrls: ['./search-station.component.css']
})
export class SearchStationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
