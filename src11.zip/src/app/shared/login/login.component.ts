import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from "@angular/material/button";
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { FormGroup, FormControl, FormsModule, ReactiveFormsModule, Validators, FormBuilder } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { JwtHelperService } from '@auth0/angular-jwt';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    CommonModule, 
    MatButtonModule, 
    MatCardModule, 
    MatFormFieldModule,
    ReactiveFormsModule,
    FormsModule,
    MatInputModule,
    MatIconModule,
  ],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  loginInfo: FormGroup;
  errorMessage: string = '';

  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private router: Router,
    private jwtHelper: JwtHelperService
  ) {
    this.loginInfo = this.fb.group({
      netId: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  ngOnInit(): void {}

  loginUser(): void {
    if (this.loginInfo.invalid) return;

    const loginPayload = {
      username: this.loginInfo.value.netId,
      password: this.loginInfo.value.password
    };

    this.http.post<any>('http://localhost:5114/api/auth/login', loginPayload).subscribe({
      next: res => {
        localStorage.setItem('token', res.token);

        const decoded = this.jwtHelper.decodeToken(res.token);
        console.log('Token decoded:', decoded);

        this.router.navigate(['/profile']); // Change route if needed
      },
      error: err => {
        console.error(err);
        this.errorMessage = 'Invalid NetID or password.';
      }
    });
  }
}
