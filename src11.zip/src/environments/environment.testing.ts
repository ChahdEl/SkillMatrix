export const environment = {
    production: true,
    appName:'Skill Matrix',
    appDesc:'Application'
  };